***********************************************
		   OSCAT
Open Source Community for Automation Technology
***********************************************


all Function Blocks within this folder are IEC 61499 implementations of the IEC 61131-3 OSCAT versions


***********************************************
	     http://www.oscat.de/
***********************************************